package com.cg.springmvctwo.service;



import java.util.List;

import com.cg.springmvctwo.dto.Mobile;

public interface MobileService {
	public void addMobile(Mobile mobile);
	public List<Mobile> showAllmobile();
	public void delateMobile(int mobId);
	public void searchMobile(int mobId);

}
