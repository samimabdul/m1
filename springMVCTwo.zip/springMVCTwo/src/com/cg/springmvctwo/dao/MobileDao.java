package com.cg.springmvctwo.dao;

import java.util.List;

import com.cg.springmvctwo.dto.Mobile;

public interface MobileDao {
	public void addMobile(Mobile mobile);
	public List<Mobile> showAllmobile();
	public void delateMobile(int mobId);
	public void searchMobile(int mobId);

}
