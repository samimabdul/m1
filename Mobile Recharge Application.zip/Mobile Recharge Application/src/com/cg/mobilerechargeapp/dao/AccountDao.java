package com.cg.mobilerechargeapp.dao;

import com.cg.mobilerechargeapp.dto.Account;

public interface AccountDao {
	 Account getAccountDetails(String mobileNo);
	    double rechargeAccount(String mobileno, double rechargeAmount);
		Account getAccount(String mobile);
}
