package com.cg.mobilerechargeapp.service;


import com.cg.mobilerechargeapp.dto.Account;
import com.cg.mobilerechargeapp.exception.AccountException;

public interface AccountService {
	Account getAccountDetails(String mobileNo);
    double rechargeAccount(String mobileno, double rechargeAmount);
    
    public boolean validateMobileNo(String mobileNo)throws AccountException;
    
    public boolean validateRechargeAmount(Double rechargeAmount)
            throws AccountException;
	

}
