package com.cg.springmvctwo.dao;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.springmvctwo.dto.Mobile;
@Repository("mobiledao")
public class MobileDaoImpl implements MobileDao{
	@PersistenceContext
 EntityManager em;
	@Override
	public void addMobile(Mobile mobile) {
		// TODO Auto-generated method stub
		em.persist(mobile);//use for make data enter into table
		em.flush();//use to exit from persist
	}

	@Override
	public List<Mobile> showAllmobile() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void delateMobile(int mobId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void searchMobile(int mobId) {
		// TODO Auto-generated method stub
		
	}
	

}
